import numpy as np
from PIL import Image
from skimage import transform, data


# def dispatch_if(operator, x, y):
#     if operator == 'add':
#         return x + y
#     elif operator == 'sub':
#         return x - y
#     elif operator == 'mul':
#         return x * y
#     elif operator == 'div':
#         return x / y
#     else:
#         return None


yasuo_image = [[0] * 94] * 60
size = (120, 180)
yasuo_image = np.array(yasuo_image)
img_t = Image.open('saidao_q_g_t.jpg')
data = np.asarray(img_t)  # 转换为矩阵
print(data.shape)  # 输出矩阵规格
print(yasuo_image.shape)
hang = 0
for h in range(60):
    lie = 0
    for l in range(94):
         yasuo_image[h][l] = data[hang][lie]
        # yasuo_image[h][l] = 60
         lie += 6
    hang += 8
image = Image.fromarray(data)  # 将之前的矩阵转换为图片
image_yasuo = Image.fromarray(yasuo_image)
image.show()
image_yasuo.show()

print("运行成功")
