


# def readData():
#     image_dir = "j.jpg"
#
#     x = Image.open(image_dir)  # 打开图片
#     data = np.asarray(x)  # 转换为矩阵
#     print(data.shape)  # 输出矩阵
#
#     image = Image.fromarray(data)  # 将之前的矩阵转换为图片
#     image.show()  # 调用本地软件显示图片，win10是叫照片的工具
#
#
# readData()
# 图片二值化
import pylab
from PIL import Image
from pylab import *
import numpy as np
import matplotlib.pyplot as pyplot
import cv2 as cv
# img = Image.open('11.jpg')
img = cv.imread('3.jpg')
# img_c = cv.imread('1.jpg')
# b,g,r = cv.split(img)
# rgb_image = cv2.merge([r,g,b])

# imGray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
img = cv.cvtColor(img, cv.COLOR_BGR2RGB)
img = cv.cvtColor(img, cv.COLOR_RGB2GRAY)

# img_c = cv.cvtColor(img_c, cv.COLOR_BGR2RGB)
# img_c = cv.cvtColor(img_c, cv.COLOR_RGB2GRAY)
# 模式L”为灰色图像，它的每个像素用8个bit表示，0表示黑，255表示白，其他数字表示不同的灰度。
# Img = img.convert('L')
# Img.show()
# Img.save("11.jpg")
# img_1 = cv.cvtColor(img,cv.COLOR_BGR2GRAY)
# cv.imshow('gray',img_1)
ig      = np.array(img)
#定义 二维数组
yasuo = [[0]*111]*84
yasuo = np.array(yasuo)
see_line = [[255]*111]*84
see_line = np.array(see_line)
# ig1=[range(168)][range(223)]
# yasuo[0][0]
# yasuo = np.array(yasuo)
# ig2 =array(img_c)
# ig.show()

# pyplot.title('f(x) = x')
# pyplot.subplot(1,2,1)

# 自定义灰度界限，大于这个值为黑色，小于这个值为白色
threshold = 128
# 图片二值化
#168行 223列
for h in range(168):
     for l in range(223):
        if ig[h][l] < threshold:
            ig[h][l] = 0   #黑色
        else:
            ig[h][l] = 255   #白色


# photo = Img.point(table, '1')
# photo.save("111.jpg")

pyplot.figure()
# pyplot.subplot(1, 1, 1)
pyplot.gray()
pyplot.imshow(ig)
pyplot.show()
print(ig.shape)
print(ig[120][100])
# 图像压缩 对高度压缩 宽度压缩
# 每隔一行调 每隔一列跳

hang  = 0
for h in range(84):
    lie   = 0
    for l in range(111):
        yasuo[h][l] = ig[hang][lie]
        lie += 2
    hang += 2
#找变线
#从中间向两边找  压缩后的图像后44行为有效行
#记录  yasuo[84][50] 为中点
#下次中点为上一行的中点存再see_line[][]中

#创建静态变量
class get_static:
    static_var_h        = np.array([0])
    static_var_l        = np.array([0,0]*44)
    static_start_h      = np.array([83])
    static_bianxian     = np.array([0,1])
    static_zhongdian_l  = np.array([0]*44)
    static_zhongdian_h  = np.array([0]*44)
    static_dangqianhang = np.array([83])

'''
   左线首行搜索
'''
for l_l in range(50,0,-1):#0黑色
    if yasuo[get_static.static_start_h[0]][l_l]==0 and yasuo[get_static.static_start_h[0]][l_l-1]==0:
        see_line[83][l_l+1]=0
        break
'''
   右线首行搜索
'''
for l_l in range(110,50,-1):#255白色
    if yasuo[get_static.static_start_h[0]][l_l]==255 and yasuo[get_static.static_start_h[0]][l_l-1]==255:
        see_line[83][l_l]=0
        break
'''
下一次中点计算  static_dangqianhang = np.array([0])
'''
one_flag = 1
two_flag = 0
for s_l in range(111):
    if see_line[get_static.static_dangqianhang[0]][s_l]==0:
      if two_flag == 1 and see_line[83][s_l]==0:
          get_static.static_var_l[1] = s_l #第二个点
    if see_line[get_static.static_dangqianhang[0]][s_l]==0:
      get_static.static_var_h[0] = get_static.static_start_h[0]
      if one_flag == 1:
         get_static.static_var_l[0] = s_l #第一个点
         one_flag = 0
         two_flag = 1
get_static.static_dangqianhang[0] = get_static.static_dangqianhang[0]-1

pyplot.gray()
pyplot.imshow(yasuo)
pyplot.show()
get_static.static_zhongdian_l[0] = ((get_static.static_var_l[1]-get_static.static_var_l[0])/2)+get_static.static_var_l[0]
print(yasuo.shape)
print(yasuo[42][50])
print('左')
print(get_static.static_var_l[0])
print('右')
print(get_static.static_var_l[1])
print('中')
print(get_static.static_zhongdian_l[0])
print("运行成功") # 输出矩阵